import numpy as np,random
from numpy import newaxis
from keras.utils import to_categorical
from keras.models import Sequential
from keras.layers import Dense, Dropout, Conv1D, MaxPooling1D, Flatten
from sklearn.model_selection import train_test_split
from keras.callbacks import TensorBoard
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score
from sklearn.metrics import explained_variance_score
import tensorflow as tf,math
from Proposed_SLnSO_DQN import SLNSO
import os
import warnings
warnings.filterwarnings("ignore")

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
#tf.logging.set_verbosity(tf.logging.ERROR)

DISCOUNT = 0.99
REPLAY_MEMORY_SIZE = 50_000  # How many last steps to keep for model training
MIN_REPLAY_MEMORY_SIZE = 1_000  # Minimum number of steps in a memory to start training
MINIBATCH_SIZE = 64  # How many steps (samples) to use for training
UPDATE_TARGET_EVERY = 5  # Terminal states (end of episodes)
MODEL_NAME = '2x256'
MIN_REWARD = -200  # For model save
MEMORY_FRACTION = 0.20
def MVR(actual_values,predicted_values):
    # Define actual and predicted values as numpy arrays
    actual_values = np.array(actual_values)  # Replace with your actual values
    predicted_values = np.array(predicted_values)  # Replace with your predicted values

    # Calculate the ratio of actual to predicted values
    ratios = actual_values / predicted_values

    # Calculate the mean of the ratios
    mean_ratio = np.mean(ratios)

    return mean_ratio

def classify(Data,Label,tr,P_S,fs,Mse,Rmse,Mae,Rsq,Mvr):


    x_train, x_test, y_train, y_test = train_test_split(Data, Label, train_size = tr, random_state = 42)

    class Blob:
        def __init__(self, size):
            self.size = size
            self.x = np.random.randint(0, size)
            self.y = np.random.randint(0, size)

        def __str__(self):
            return f"Blob ({self.x}, {self.y})"

        def __sub__(self, other):
            return (self.x - other.x, self.y - other.y)

        def __eq__(self, other):
            return self.x == other.x and self.y == other.y

        def action(self, choice):
            '''
            Gives us 9 total movement options. (0,1,2,3,4,5,6,7,8)
            '''
            if choice == 0:
                self.move(x=1, y=1)
            elif choice == 1:
                self.move(x=-1, y=-1)
            elif choice == 2:
                self.move(x=-1, y=1)
            elif choice == 3:
                self.move(x=1, y=-1)

            elif choice == 4:
                self.move(x=1, y=0)
            elif choice == 5:
                self.move(x=-1, y=0)

            elif choice == 6:
                self.move(x=0, y=1)
            elif choice == 7:
                self.move(x=0, y=-1)

            elif choice == 8:
                self.move(x=0, y=0)

        def move(self, x=False, y=False):

            # If no value for x, move randomly
            if not x:
                self.x += np.random.randint(-1, 2)
            else:
                self.x += x

            # If no value for y, move randomly
            if not y:
                self.y += np.random.randint(-1, 2)
            else:
                self.y += y

            # If we are out of bounds, fix!
            if self.x < 0:
                self.x = 0
            elif self.x > self.size - 1:
                self.x = self.size - 1
            if self.y < 0:
                self.y = 0
            elif self.y > self.size - 1:
                self.y = self.size - 1

    class BlobEnv:
        SIZE = 10
        RETURN_IMAGES = True
        MOVE_PENALTY = 1
        ENEMY_PENALTY = 300
        FOOD_REWARD = 25
        OBSERVATION_SPACE_VALUES = np.shape(x_train)  # (SIZE, SIZE, 3)  # 4
        ACTION_SPACE_SIZE = 9
        PLAYER_N = 1  # player key in dict
        FOOD_N = 2  # food key in dict
        ENEMY_N = 3  # enemy key in dict
        # the dict! (colors)
        d = {1: (255, 175, 0),
             2: (0, 255, 0),
             3: (0, 0, 255)}

        def reset(self):
            self.player = Blob(self.SIZE)
            self.food = Blob(self.SIZE)
            while self.food == self.player:
                self.food = Blob(self.SIZE)
            self.enemy = Blob(self.SIZE)
            while self.enemy == self.player or self.enemy == self.food:
                self.enemy = Blob(self.SIZE)

            self.episode_step = 0

            if self.RETURN_IMAGES:
                observation = np.array(self.get_image( ))
            else:
                observation = (self.player - self.food) + (self.player - self.enemy)
            return observation

        def step(self, action):
            self.episode_step += 1
            self.player.action(action)

            #### MAYBE ###
            # enemy.move()
            # food.move()
            ##############

            if self.RETURN_IMAGES:
                new_observation = np.array(self.get_image( ))
            else:
                new_observation = (self.player - self.food) + (self.player - self.enemy)

            if self.player == self.enemy:
                reward = -self.ENEMY_PENALTY
            elif self.player == self.food:
                reward = self.FOOD_REWARD
            else:
                reward = -self.MOVE_PENALTY

            done = False
            if reward == self.FOOD_REWARD or reward == -self.ENEMY_PENALTY or self.episode_step >= 200:
                done = True

            return new_observation, reward, done

    env = BlobEnv( )

    # Own Tensorboard class
    class ModifiedTensorBoard(TensorBoard):

        # Overriding init to set initial step and writer (we want one log file for all .fit() calls)
        def __init__(self, **kwargs):
            super( ).__init__(**kwargs)
            self.step = 1
            self.writer = tf.summary.FileWriter(self.log_dir)

        # Overriding this method to stop creating default log writer
        def set_model(self, model):
            pass

        # Overrided, saves logs with our step number
        # (otherwise every .fit() will start writing from 0th step)
        def on_epoch_end(self, epoch, logs=None):
            self.update_stats(**logs)

        # Overrided
        # We train for one batch only, no need to save anything at epoch end
        def on_batch_end(self, batch, logs=None):
            pass

        # Overrided, so won't close writer
        def on_train_end(self, _):
            pass

        # Custom method for saving own metrics
        # Creates writer, writes custom metrics and closes writer
        def update_stats(self, **stats):
            self._write_logs(stats, self.step)

    # Agent class
    class DQNAgent:
        def __init__(self, train_data, train_label, test_data, test_label, pred):

            # Main model
            self.model = self.create_model(train_data, train_label, test_data, test_label, pred)

        def create_model(self, train_data, train_label, test_data, test_label, pred):
            train_data = train_data.astype('float32')
            test_data = test_data.astype('float32')
            train_data = train_data / np.max(train_data)
            test_data = test_data / np.max(test_data)

            train_x = train_data[:, :, newaxis]
            train_y = to_categorical(train_label)
            test_x = test_data[:, :, newaxis]
            #test_y = to_categorical(test_label)

            # evaluate model
            verbose, epochs, batch_size = 0, 5, 1000
            n_timesteps, n_features, n_outputs = train_x.shape[1], train_x.shape[2], train_y.shape[1]
            model = Sequential()
            model.add(Conv1D(32, kernel_size=3, activation='relu', input_shape=(n_timesteps, n_features)))
            model.add(Conv1D(64, kernel_size=3, activation='relu'))
            model.add(Dropout(0.5))
#            model.add(MaxPooling1D(pool_size=2))
            model.add(Flatten())
            model.add(Dense(100, activation='relu'))
            model.add(Dense(50, activation='relu'))
            model.add(Dense(n_outputs, activation='softmax'))
            model.compile(loss="categorical_crossentropy", optimizer='adam', metrics=['accuracy'])
            tf.keras.utils.plot_model(model, to_file='DQN.png', show_shapes=True,
                                      show_layer_names=True)
            init_weight = model.get_weights()
            #rw, cw = len(init_wei), len(init_wei[0])  # row, columns in weight array
            model.set_weights(init_weight + SLNSO.Algm(P_S, fs, Label))

            # fit network
            model.fit(train_x, train_y, epochs=epochs, batch_size=batch_size, verbose=0)
            predict = model.predict(test_x)
            for i in range(len(predict)): pred.append(predict[i])
            return model

        # Adds step's data to a memory replay array
        # (observation space, action, reward, new observation space, done)
        def update_replay_memory(self, transition):
            self.replay_memory.append(transition)

        # Trains main network every step during episode
        def train(self, terminal_state, step):

            # Start training only if certain number of samples is already saved
            if len(self.replay_memory) < MIN_REPLAY_MEMORY_SIZE:
                return

            # Get a minibatch of random samples from memory replay table
            minibatch = random.sample(self.replay_memory, MINIBATCH_SIZE)

            # Get current states from minibatch, then query NN model for Q values
            current_states = np.array([transition[0] for transition in minibatch]) / 255
            current_qs_list = self.model.predict(current_states)

            # Get future states from minibatch, then query NN model for Q values
            # When using target network, query it, otherwise main network should be queried
            new_current_states = np.array([transition[3] for transition in minibatch]) / 255
            future_qs_list = self.target_model.predict(new_current_states)

            X = []
            y = []

            # Now we need to enumerate our batches
            for index, (current_state, action, reward, new_current_state, done) in enumerate(minibatch):

                # If not a terminal state, get new q from future states, otherwise set it to 0
                # almost like with Q Learning, but we use just part of equation here
                if not done:
                    max_future_q = np.max(future_qs_list[index])
                    new_q = reward + DISCOUNT * max_future_q
                else:
                    new_q = reward

                # Update Q value for given state
                current_qs = current_qs_list[index]
                current_qs[action] = new_q

                # And append to our training data
                X.append(current_state)
                y.append(current_qs)

            # Fit on all samples as one batch, log only on terminal state
            self.model.fit(np.array(X) / 255, np.array(y), batch_size=MINIBATCH_SIZE, verbose=0, shuffle=False,
                           callbacks=[self.tensorboard] if terminal_state else None)

            # Update target network counter every episode
            if terminal_state:
                self.target_update_counter += 1

            # If counter reaches set value, update target network with weights of main network
            if self.target_update_counter > UPDATE_TARGET_EVERY:
                self.target_model.set_weights(self.model.get_weights( ))
                self.target_update_counter = 0

        # Queries main network for Q values given current observation space (environment state)
        def get_qs(self, state):
            return self.model.predict(np.array(state).reshape(-1, *state.shape) / 255)[0]

    pred = []
    agent = DQNAgent(np.array(x_train), np.array(y_train), np.array(x_test), np.array(y_test), pred)




    mse=mean_squared_error(y_test, pred)
    rmse = math.sqrt(mse)
    mae_ = mean_absolute_error(y_test, pred)
    rsco=r2_score(y_test,pred)
    mean_value_ratio=MVR(y_test,pred)

    Mse.append(mse)
    Rmse.append(rmse)
    Mae.append(mae_)
    Rsq.append(rsco)
    Mvr.append(mean_value_ratio)

