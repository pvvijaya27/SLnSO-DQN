import random

import Proposed_SLnSO_DQN.Levenshtein as lev

# Damerau-Levenshtein distance (for feature selection)
def levenshtein(data_1, data_2):
    return lev.levenshtein_distance(data_1, data_2, ratio_calc=True)

def func(data,target):

    Fit = []
    for i in range(len(data)):
        Fit.append(levenshtein(data[i], target))  # levenshtein value of attributes in mapper data


    return Fit
