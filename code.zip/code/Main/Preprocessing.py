import pandas as pd
from sklearn.preprocessing import PowerTransformer
import numpy as np

def YJ_transformation(data):
    pt = PowerTransformer( )
    pt.fit(data)
    PowerTransformer(copy=True, method='yeo-johnson', standardize=True)  #Preprocessing by using yeo-johnson
    return pt.transform(data)
def preprocess(dts):

    Data=pd.read_csv("Dataset/"+dts+"_.csv")
    Data=np.array(Data)
    if(dts=="student-mat"):
        Label=Data[:,-5]
    else:
        Label=Data[:,-1]
    data=YJ_transformation(Data)

    return data,Label


