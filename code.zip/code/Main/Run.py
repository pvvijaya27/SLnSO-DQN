import Preprocessing
from Main.Feature_selection import Feature
from Main.DataAgumentation import BootStrap
from Proposed_SLnSO_DQN import DQN


dts='student-mat'
tr=0.9
p_s=10
MSE,RMSE,MAE,Rsq,MVR=[],[],[],[],[]
Data,Label=Preprocessing.preprocess(dts)  #Data transformation (Yeo-Jhonson)

Feature_size=5  #  Feature size

#feature selection using Squirrel search alg + Sea Lion Optimization Algorithm, fitness: Damerau–Levenshtein distance
Data= Feature.selection(Data, Label, Feature_size)
# Data augmentation  using Bootstrap
Agu_data,Aug_label=BootStrap.data_agumentation(Data,Label)

#performance prediction to find at - risk students using deep Q network, where the training will be based on Squirrel search alg + Sea  Lion Optimization Algorithm

DQN.classify(Agu_data,Aug_label,tr,p_s,Feature_size,MSE,RMSE,MAE,Rsq,MVR)   # Proposed







