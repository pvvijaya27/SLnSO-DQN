# scikit-learn bootstrap
from sklearn.utils import resample
import numpy as np
# data sample

def data_agumentation(data,label):

    # prepare bootstrap sample
    boot = resample(data, replace=True, n_samples=1000, random_state=1)

    # out of bag observations
    oob = [x for x in data if x not in boot]

    Label = np.resize(label, len(boot))

    return boot,Label