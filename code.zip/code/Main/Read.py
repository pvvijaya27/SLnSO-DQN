import pandas as pd
import numpy as np

Data=pd.read_csv("Dataset\\student-mat.csv")
a = np.shape(Data)[1]
Array = ["school", "sex", "address", "famsize", "Pstatus", "Mjob","Fjob","reason","guardian","schoolsup","famsup"
         ,"paid","activities","nursery","higher","internet","romantic"]

Dataset=[]
Header=Data.columns
for i in range(len(Header)):
    if (Header[i] in Array):
        str_to_convert = Data[Header[i]].values.tolist()
        union=np.unique(str_to_convert).tolist()   #Taking unique for the string present in dataset
        ind_rep = []
        for k in range(len(str_to_convert)):
            ind_rep.append(union.index(str_to_convert[k]))  # appending the index of the string
        Dataset.append(ind_rep)
    else:
        Dataset.append(Data[Header[i]].values.tolist())
print(Dataset)
Dataset=np.transpose(Dataset)
#np.savetxt("Dataset\\student-mat_.csv",Dataset,delimiter=",",fmt="%s")

#2nd Dataset
Data=pd.read_csv("Dataset/DATA.csv")
a = np.shape(Data)[1]
Array = ["STUDENT ID"]

Dataset=[]
Header=Data.columns
for i in range(len(Header)):
    if (Header[i] in Array):
        str_to_convert = Data[Header[i]].values.tolist()
        union=np.unique(str_to_convert).tolist()   #Taking unique for the string present in dataset
        ind_rep = []
        for k in range(len(str_to_convert)):
            ind_rep.append(union.index(str_to_convert[k]))  # appending the index of the string
        Dataset.append(ind_rep)
    else:
        Dataset.append(Data[Header[i]].values.tolist())
print(Dataset)
Dataset=np.transpose(Dataset)
np.savetxt("Dataset\\DATA_.csv",Dataset,delimiter=",",fmt="%s")