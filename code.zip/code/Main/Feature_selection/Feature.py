import numpy as np
from Main.Feature_selection import SSA


def selection(data, clas, fs):

    selected_attr=SSA.Algm(data,clas,fs) 

    Feature_SelectedData = data[:, selected_attr]  # Selected feature

    return Feature_SelectedData    # returns selected feature index of mapper data

